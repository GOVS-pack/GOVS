## ---- include = FALSE,echo=FALSE,results='hide',message=FALSE-----------------
require(GOVS)
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval=FALSE,echo=TRUE,include=TRUE----------------------------------------
#  ## install dependencies and GOVS
#  install.packages(c("ggplot2","rrBLUP","lsmeans","readr","pbapply","pheatmap","emmeas"))
#  require("devtools")
#  install_github("GOVS-pack/GOVS")
#  ## if you want build vignette in GOVS
#  install_github("GOVS-pack/GOVS",build_vignettes = TRUE)

## ----eval = FALSE,echo=TRUE---------------------------------------------------
#  ## install dependencies and GOVS with bult-in vignette
#  install.packages(c("ggplot2","rrBLUP","lsmeans","readr","pbapply","pheatmap","emmeas"))
#  install.packages("DownloadPath/GOVS_1.0.tar.gz")

## ----eval=FALSE,echo=TRUE-----------------------------------------------------
#  library("GOVS")

## ----echo=TRUE,include=TRUE,message=FALSE,warning=FALSE-----------------------
data(MZ)
MZ[1:10,1:15]

## ----echo=TRUE,include=TRUE,message=FALSE,warning=FALSE-----------------------
data(phe)
head(phe)

## ----echo=TRUE,include=TRUE,message=FALSE,warning=FALSE-----------------------
data(bins)
bins[1:5,1:5]

## ----echo=TRUE,include=TRUE,message=FALSE,warning=FALSE-----------------------
data("binsInfo")
head(binsInfo)

## ----echo=TRUE,include=TRUE,message=FALSE,warning=FALSE,eval=FALSE------------
#  GOVS_res <- GOVS(MZ,pheno = phe,trait = "EW",which = "max",bins = bins,
#                   binsInfo = binsInfo,module = "DES")

## ----include=TRUE,echo=TRUE,eval=FALSE----------------------------------------
#  GOVS_res$statRes

## ----include=TRUE,echo=TRUE,message=FALSE-------------------------------------
## load hapmap data (genomic data) of MZ hybrids
data(MZ)
## load phenotypic data of MZ hybrids
data(phe)
## pre-process for G2P prediction 
rownames(MZ) <- MZ[,1]
MZ <- MZ[,-c(1:11)]
MZ.t <- t(MZ)
## conversion
MZ.n <- transHapmap2numeric(MZ.t)
dim(MZ.t)
## prediction
idx1 <- sample(1:1404,1000)
idx2 <- setdiff(1:1404,idx1)
predRes <- SNPrrBLUP(MZ.n,phe$EW,idx1,idx2,fix = NULL,model = FALSE)

head(predRes)

## ----include=TRUE,echo=TRUE,message=FALSE,fig.height=4.5,fig.width=7----------
## scatter plot 
plot(phe$EW[idx2],predRes,xlab = "Observed value", ylab =  "Predicted value")

## ----eval=FALSE,echo=T--------------------------------------------------------
#  ## load example data
#  data(IBDTestData)
#  
#  ## compute rou from genetic position
#  rou = IBDTestData$posGenetic
#  rou = diff(rou)
#  rou = ifelse(rou<0,0,rou)
#  
#  ## constract IBD map of chr10 for one progeny
#  IBDRes <- IBDConstruct(snpParents = IBDTestData$snpParents,
#  markerInfo = IBDTestData$markerInfo,
#  snpProgeny = IBDTestData$snpProgeny,q = 0.97,G = 9,rou = rou)

## ----eval=FALSE,echo=TRUE-----------------------------------------------------
#  ## load example data
#  data(IBDTestData)
#  
#  ## compute rou from genetic position
#  rou = IBDTestData$posGenetic
#  rou = diff(rou)
#  rou = ifelse(rou<0,0,rou)
#  
#  ## constract IBD map of chr10 for one progeny
#  IBDRes <- IBDConstruct(snpParents = IBDTestData$snpParents,
#  markerInfo = IBDTestData$markerInfo,
#  snpProgeny = IBDTestData$snpProgeny,q = 0.97,G = 9,rou = rou)
#  
#  ## plot
#  # color
#  color <- c("#DA053F","#FC0393","#C50F84","#D870D4","#DCA0DC","#4A0380",
#             "#9271D9","#0414FB","#2792FC","#4883B2","#2CFFFE","#138B8A",
#             "#42B373","#9BFB9C","#84FF2F","#566B32","#FED62D","#FD8A21",
#             "#F87E75","#B01D26","#7E0006","#A9A9A9","#FFFE34","#FEBFCB")
#  names(color) <- 1:24
#  
#  # parent label
#  parentInfo <- c("5237","E28","Q1261","CHANG7-2","DAN340","HUANGC","HYS",
#                  "HZS","TY4","ZI330","ZONG3","LX9801","XI502","81515",
#                  "F349","H21","JI853","JI53","LV28","YUANFH","SHUANG741",
#                  "K12","NX110","ZONG31")
#  names(parentInfo) <- 1:24
#  
#  # plot
#  binsPlot(IBDRes,color,parentInfo,24)

## ----echo=TRUE,eval=FALSE-----------------------------------------------------
#  ## load data
#  data(bins)
#  data(binsInfo)
#  ## color
#  color <- c("#DA053F","#FC0393","#C50F84","#D870D4","#DCA0DC","#4A0380",
#              "#9271D9","#0414FB","#2792FC","#4883B2","#2CFFFE","#138B8A",
#              "#42B373","#9BFB9C","#84FF2F","#566B32","#FED62D","#FD8A21",
#              "#F87E75","#B01D26","#7E0006","#A9A9A9","#FFFE34","#FEBFCB")
#  
#  mosaicPlot(bins = bins,binsInfo = binsInfo,chr = 1,resolution = 500,
#                    color = color,
#                    list = colnames(bins)[1:200])

